# spurgeon

This app gets a random image and pairs it with a Spurgeon quote of the day.
It uses Unsplash and Netlify.
